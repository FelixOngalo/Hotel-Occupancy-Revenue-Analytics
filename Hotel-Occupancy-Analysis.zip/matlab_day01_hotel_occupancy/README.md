# Day 01 – Hotel Occupancy & Revenue Analysis

## Brief description
This mid-level MATLAB project analyses one year of hotel room-performance data to evaluate occupancy, Average Daily Rate (ADR), room revenue, and RevPAR. It also compares weekday and weekend demand, identifies high-demand dates, measures the relationship between occupancy and ADR, and produces management-oriented visualisations.

## Skills demonstrated
- Importing and validating tabular data
- Data cleaning and missing-value handling
- KPI calculation
- Grouped/monthly analysis
- Correlation analysis
- Data visualisation
- Business interpretation
- Exporting analytical results

## Key hospitality KPIs
- **Occupancy Rate:** rooms occupied ÷ rooms available
- **ADR:** average revenue earned per occupied room
- **RevPAR:** room revenue ÷ rooms available

## Project structure
```text
Day-01-Hotel-Occupancy-Analysis/
├── data/
│   └── hotel_occupancy_2025.csv
├── src/
│   └── hotel_occupancy_analysis.m
├── figures/
│   ├── daily_occupancy_trend.png
│   ├── monthly_occupancy_revpar.png
│   └── occupancy_vs_adr.png
├── results/
│   └── kpi_summary.csv
└── README.md
```

## How to run
Open MATLAB, set the project folder as the Current Folder, then run:

```matlab
src/hotel_occupancy_analysis.m
```

The script reads the CSV data, calculates KPIs, creates three figures, and exports a KPI summary.

## Dataset
The dataset is synthetic and created for portfolio/learning purposes. It is designed to resemble daily hotel room-performance data without using real guest information.

## Portfolio progression
This is intended as Day 01 of a larger hospitality analytics portfolio. A natural next project is **hotel demand forecasting**, followed by dynamic pricing and guest behaviour modelling.

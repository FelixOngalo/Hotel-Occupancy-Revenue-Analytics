%% Day 01 - Hotel Occupancy & Revenue Analysis
% Mid-level MATLAB portfolio project
% Skills: data import, cleaning, KPI calculation, grouping, visualization,
% correlation analysis, and management-oriented interpretation.

clear; clc; close all;

%% 1. Load data
dataFile = fullfile("data","hotel_occupancy_2025.csv");
T = readtable(dataFile);

% Convert date if needed
T.Date = datetime(T.Date);

%% 2. Validate and prepare data
requiredVars = ["Date","Rooms_Available","Rooms_Occupied","Occupancy_Rate", ...
                "ADR","Room_Revenue","RevPAR"];
assert(all(ismember(requiredVars, string(T.Properties.VariableNames))), ...
    "Required variables are missing from the dataset.");

% Remove duplicate dates and rows with missing KPI values
T = sortrows(T,"Date");
[~, uniqueIdx] = unique(T.Date,"stable");
T = T(uniqueIdx,:);
T = rmmissing(T, "DataVariables", requiredVars);

% Recalculate core KPIs to ensure consistency
T.Occupancy_Rate = T.Rooms_Occupied ./ T.Rooms_Available;
T.Room_Revenue = T.Rooms_Occupied .* T.ADR;
T.RevPAR = T.Room_Revenue ./ T.Rooms_Available;

%% 3. Calculate overall KPIs
overallOccupancy = mean(T.Occupancy_Rate);
overallADR = mean(T.ADR);
totalRoomRevenue = sum(T.Room_Revenue);
overallRevPAR = totalRoomRevenue / sum(T.Rooms_Available);

fprintf("\n===== HOTEL PERFORMANCE SUMMARY =====\n");
fprintf("Average occupancy : %.1f%%\n", overallOccupancy*100);
fprintf("Average ADR       : %.2f\n", overallADR);
fprintf("Total room revenue: %.2f\n", totalRoomRevenue);
fprintf("RevPAR            : %.2f\n", overallRevPAR);

%% 4. Monthly performance
T.MonthNum = month(T.Date);
monthly = groupsummary(T,"MonthNum","mean", ...
    ["Occupancy_Rate","ADR","RevPAR"]);

% Sort by calendar month
monthly = sortrows(monthly,"MonthNum");

fprintf("\n===== MONTHLY PERFORMANCE =====\n");
disp(monthly(:,["MonthNum","mean_Occupancy_Rate","mean_ADR","mean_RevPAR"]));

%% 5. Weekend vs weekday performance
isWeekend = ismember(weekday(T.Date), [6 7]); % Saturday/Sunday
weekendOcc = mean(T.Occupancy_Rate(isWeekend));
weekdayOcc = mean(T.Occupancy_Rate(~isWeekend));

fprintf("\n===== WEEKDAY / WEEKEND =====\n");
fprintf("Weekday occupancy : %.1f%%\n", weekdayOcc*100);
fprintf("Weekend occupancy : %.1f%%\n", weekendOcc*100);

%% 6. Occupancy and ADR relationship
[r,p] = corr(T.Occupancy_Rate, T.ADR, "Rows","complete");
fprintf("\nCorrelation between occupancy and ADR: r = %.3f (p = %.4f)\n", r, p);

%% 7. Identify high-demand days
highDemandThreshold = 0.85;
highDemand = T(T.Occupancy_Rate >= highDemandThreshold,:);
highDemand = sortrows(highDemand,"Occupancy_Rate","descend");

fprintf("\n===== TOP HIGH-DEMAND DAYS =====\n");
disp(highDemand(:,["Date","Occupancy_Rate","ADR","RevPAR"]));

%% 8. Visualization - occupancy trend
figure("Name","Daily Occupancy Trend");
plot(T.Date, T.Occupancy_Rate*100, "LineWidth", 1.2);
hold on;
yline(highDemandThreshold*100, "--", "High-demand threshold");
xlabel("Date");
ylabel("Occupancy (%)");
title("Daily Hotel Occupancy - 2025");
grid on;
exportgraphics(gcf, fullfile("figures","daily_occupancy_trend.png"), "Resolution", 180);

%% 9. Visualization - monthly KPIs
figure("Name","Monthly KPIs");
yyaxis left
plot(monthly.MonthNum, monthly.mean_Occupancy_Rate*100, "-o", "LineWidth", 1.4);
ylabel("Average Occupancy (%)");
yyaxis right
plot(monthly.MonthNum, monthly.mean_RevPAR, "-s", "LineWidth", 1.4);
ylabel("RevPAR");
xlabel("Month");
title("Monthly Occupancy and RevPAR");
xticks(1:12);
grid on;
exportgraphics(gcf, fullfile("figures","monthly_occupancy_revpar.png"), "Resolution", 180);

%% 10. Visualization - occupancy vs ADR
figure("Name","Occupancy vs ADR");
scatter(T.Occupancy_Rate*100, T.ADR, 28, "filled");
xlabel("Occupancy (%)");
ylabel("Average Daily Rate (ADR)");
title(sprintf("Occupancy vs ADR (r = %.2f)", r));
grid on;
exportgraphics(gcf, fullfile("figures","occupancy_vs_adr.png"), "Resolution", 180);

%% 11. Save a concise results table
summary = table(overallOccupancy, overallADR, totalRoomRevenue, overallRevPAR, ...
    weekdayOcc, weekendOcc, r, p, ...
    'VariableNames', {'AverageOccupancy','AverageADR','TotalRoomRevenue', ...
    'RevPAR','WeekdayOccupancy','WeekendOccupancy','Occupancy_ADR_Correlation','PValue'});
writetable(summary, fullfile("results","kpi_summary.csv"));

%% 12. Management interpretation
fprintf("\n===== MANAGEMENT INTERPRETATION =====\n");
fprintf("1. Use high-demand periods to test revenue-management price increases.\n");
fprintf("2. Compare weekday and weekend demand when planning promotions.\n");
fprintf("3. Monitor RevPAR alongside occupancy; high occupancy alone does not guarantee maximum revenue.\n");
fprintf("4. Investigate dates above the %.0f%% occupancy threshold for events or demand spikes.\n", highDemandThreshold*100);
fprintf("5. Use the occupancy-ADR relationship as an input to a future dynamic-pricing model.\n");
